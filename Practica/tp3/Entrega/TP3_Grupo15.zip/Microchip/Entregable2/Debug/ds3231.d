ds3231.d ds3231.o: .././ds3231.c .././ds3231.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 .././i2c.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\io.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\sfr_defs.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h \
 D:\WindowsStuff\ProgramasWin\MicrochipStudio\7.0\Packs\atmel\ATmega_DFP\1.6.364\include/avr/iom328p.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\portpins.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\common.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\version.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\fuse.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\lock.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\util\twi.h

.././ds3231.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

.././i2c.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\io.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\sfr_defs.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h:

D:\WindowsStuff\ProgramasWin\MicrochipStudio\7.0\Packs\atmel\ATmega_DFP\1.6.364\include/avr/iom328p.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\portpins.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\common.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\version.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\fuse.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\lock.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\util\twi.h:
