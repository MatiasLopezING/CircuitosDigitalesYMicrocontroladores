parser.d parser.o: .././parser.c .././parser.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\string.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdio.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdarg.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdbool.h \
 .././ds3231.h

.././parser.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\string.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdio.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdarg.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdbool.h:

.././ds3231.h:
