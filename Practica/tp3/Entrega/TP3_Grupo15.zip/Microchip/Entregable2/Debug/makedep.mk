################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

dht11.c

parser.c

terminal.c

ds3231.c

timer.c

i2c.c

uart.c

main.c

