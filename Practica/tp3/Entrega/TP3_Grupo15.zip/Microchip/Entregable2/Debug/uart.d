uart.d uart.o: .././uart.c .././uart.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\io.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\sfr_defs.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 D:\WindowsStuff\ProgramasWin\MicrochipStudio\7.0\Packs\atmel\ATmega_DFP\1.6.364\include/avr/iom328p.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\portpins.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\common.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\version.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\fuse.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\lock.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdbool.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\string.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h \
 d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\interrupt.h

.././uart.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\io.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\sfr_defs.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

D:\WindowsStuff\ProgramasWin\MicrochipStudio\7.0\Packs\atmel\ATmega_DFP\1.6.364\include/avr/iom328p.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\portpins.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\common.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\version.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\fuse.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\lock.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdbool.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\string.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h:

d:\windowsstuff\programaswin\microchipstudio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\interrupt.h:
