twi.d twi.o: .././twi.c
